# Product Steering: EKYAN Connect

## Vision
Help EKYAN scale from roughly **74,000 farmers and 512 agripreneurs** toward its ambition of **2 million smallholder farmers and 6,000–50,000 agripreneurs by 2028**, without losing quality, by giving the programme a **working structure**: one connected system where needs and blockers are reported, acted on, and measured.

## The programme in one paragraph
EKYAN equips young people, especially young women, with skills, digital tools and resources for agribusiness, while promoting regenerative, climate-smart agriculture. Youth **agripreneurs** each serve roughly 100–500 local **farmers** with advice and services. **Schools** act as community hubs (64 Centres of Excellence). County government anchors delivery. Delivery partners include Kuza (Ask Nia, OneNetwork, Agribytes, Leadership Academy), SNV and 40+ private-sector partners, with finance partners such as SEVi, 4G Capital and Pepea Capital.

## The core problem we are solving
Training works, but **knowledge does not reliably turn into action and income.**
- 220,000+ farmer adoption intentions; verification found ~66% fully adopted.
- Barriers named by the programme: inputs, capital/finance, water, labour, markets.
- These barriers are captured **after the fact** (surveys, verification visits). There is **no live channel** for farmers to report what is blocking them, and no workflow to resolve it.
- Last-mile input access is named by the programme as the **priority growth constraint**.
- Out-of-school youth: income +21% vs +30% target; ~10% employment vs 40% target.

## Who we serve (actors)
| Actor | Primary need |
|---|---|
| Farmer | Get inputs, advice, finance and a buyer at the right time |
| Agripreneur | Serve more farmers efficiently, build a bankable business |
| Supplier | See real, pooled rural demand worth serving |
| Lender | Evidence to lend to people with no collateral or credit history |
| Buyer / off-taker | Reliable volume and quality |
| County extension officer | Know where scarce staff time matters most |
| UNICEF / GenU programme team | One trusted view of outcomes and cost per outcome |

## MVP scope (pilot: poultry value chain, Busia County)
1. **Field Log**: agripreneur logs farmer orders, blockers and sales (offline-capable).
2. **Blocker Resolution**: blockers are categorised, routed and tracked to resolution.
3. **Pooled Demand Board**: suppliers see aggregated demand and commit to supply.
4. **Bookkeeping & Credit-Readiness Profile**: transactions build a consented, explainable profile.
5. **Programme Dashboard**: KPIs, blocker trends, adoption funnel, cost per outcome.

## Out of scope for MVP
Real payments, real lending decisions, live integration with Kuza systems, production ML credit models, value-addition/processing modules, multi-country rollout (design for it; don't build it).

## Product principles
1. **Empathy first**: design for a farmer with a basic phone, limited data and limited time.
2. **Reuse before build**.
3. **One entry, many uses**: the agripreneur logs once; the data feeds orders, profile and dashboard.
4. **Evidence over anecdote**: every KPI has one definition and one source.
5. **Configurable, not hard-coded**: value chains, counties, languages, partners are data, not code.
6. **Inclusive by default**: women, youth with disabilities, arid/pastoral contexts.
