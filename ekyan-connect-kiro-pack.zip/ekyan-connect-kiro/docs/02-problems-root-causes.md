# 02 · Problems and Root Causes

| # | Problem | Evidence | Root cause | What the system must do |
|---|---|---|---|---|
| P1 | Training doesn't fully turn into action | 220k+ intentions; ~66% verified full adoption; barriers: inputs, capital, water, labour, markets | No live channel to report blockers; no resolution workflow | Capture blockers live; route; track to resolution |
| P2 | Inputs hard to reach | "Priority growth constraint" (scale plan) | Demand fragmented and invisible to suppliers | Pool demand by item, place and date |
| P3 | Finance out of reach | Youth seen as high-risk; limits KES 20–50k; Chomoka early issues | No formal records or collateral | Bookkeeping → consented credit-readiness profile |
| P4 | Unreliable markets | Unstable prices, few buyers in remote areas, weak aggregation | Supply not visible before harvest | Supply forecast and buyer interest board (phase 2) |
| P5 | Hard to scale the human model | 15-week academy + county mentoring; 512 → 6k–50k agripreneurs | Quality depends on mentor capacity | Digital tools that save agripreneur time; coaching nudges |
| P6 | Uneven advisory | Ask Nia strongest in poultry; accuracy concern | Narrow coverage; unverified sources | Route questions to Ask Nia; verified-source policy; escalation |
| P7 | Inconsistent data | Self-reported; conflicting figures across documents | No single source of truth | One KPI dictionary; audited data; dashboard |
| P8 | Out-of-school youth miss targets | +21% vs +30% income; ~10% vs 40% jobs | Weakest market and finance links | Include them as agripreneur/aggregator roles in the same flows |
| P9 | Context and inclusion | Samburu water/pastoral; women time/labour/land | One-size-first model | Configurable value chains and categories; voice; accessibility |

## Data consistency notes (to raise tactfully with the programme team)
| Measure | Values seen |
|---|---|
| Farmers reached | 69,000 / 73,558 / 74,000 |
| Female share of farmers | 65% / 62% / 48% |
| School harvest | 4,591 kg / 4,951 kg |
| Climate-coping ability | 99% / 79% |
| Median income increase | "$130K" on one slide (KES 17,000 elsewhere) |
| 2028 farmer target | written "2,000,0000" |

These are why P7 matters: the dashboard must define each KPI once.
