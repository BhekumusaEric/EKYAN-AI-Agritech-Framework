# 06 · Open Questions (validate before Phase 2)

1. How do farmers report problems today, and who acts on them?
2. Farmer phone access: smartphone, feature phone, none? Share by county?
3. What does OneNetwork's marketplace already do (input ordering, produce sales)? APIs?
4. What can Ask Nia do beyond poultry? Is there an API?
5. Next-phase KPIs and cost-per-outcome targets?
6. Can a pilot attach to the poultry bundle? Which suppliers/finance partner?
7. Data-sharing agreement and data-protection requirements (UNICEF, Kenya DPA)?
8. Independent evaluation timing; can its baseline be used?
9. Nigeria: same model or different priorities?
10. UNICEF/FNB brand or UX guidelines to follow?
11. Formal role and arrangement for Bhek.
