# 05 · Roadmap and Pilot

| Phase | When | What | Proof |
|---|---|---|---|
| 0 Validate | Now – Nov 2026 | Gap map, data notes, interviews (Manuela, Kuza, agripreneurs) | Agreed problems and KPIs |
| 1 Prototype | Nov – Dec 2026 | This MVP on synthetic data; demo to UNICEF team | Team sign-off |
| 2 Pilot | Early 2027 | Busia poultry: blockers + pooled orders + bundle finance + buyer | K2, K4, K6 improve vs baseline |
| 3 Scale | 2027 – 2028 | More value chains, Kuza integration, Nigeria configuration | Cost per outcome falls as reach grows |

## Why Busia poultry first
- Poultry has the highest adoption willingness (82,967 intentions).
- A poultry bundle (chicks, feed, vaccines, training, buyers) is already being designed.
- Ask Nia is strongest in poultry.

## Pilot design (draft)
- 10–20 agripreneurs, their farmers, 2–3 suppliers, 1 finance partner, 1 buyer.
- 8–12 weeks; baseline in weeks 1–2.
- Weekly review with programme team.

## Bhek's role (proposed)
Youth Advisor – AI & Digital Innovation: BA, solution architecture, prototyping, credit-readiness design input (lender perspective), youth co-design. ~4–6 hrs/week for 90 days; arrangement to be confirmed in writing.
