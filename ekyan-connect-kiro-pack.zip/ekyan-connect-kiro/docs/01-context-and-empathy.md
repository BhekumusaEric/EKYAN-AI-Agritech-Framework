# 01 · Context and Empathy

## 1. What we heard in the meeting
In the UNICEF GenU AI Chat, Manuela Radelsboeck (UNICEF GenU) described where technology could help EKYAN:
- **Advisory:** farmers and agripreneurs need accurate, quality information when they need it (e.g. diseases). Accuracy is a concern.
- **Inputs:** finding seeds, fertiliser and the best prices.
- **Markets:** finding off-takers and selling what is produced.
- **Finance:** bookkeeping, transactions and proving creditworthiness.
- **Value addition:** what happens after primary production (later scope).
- **Targets:** measured in numbers, **and in cost-effectiveness**.
- **Timing:** current phase ends late November; next phase early 2027 at the latest; Nigeria may follow.

Commitment made: research the challenges, check what already exists, map challenges to targets, then present and possibly prototype.

## 2. Programme facts (from the documents)
| Item | Value |
|---|---|
| School Centres of Excellence | 64 |
| Agripreneurs incubated | 512 |
| Farmers trained / served | ~69,000–74,000 (figures vary across documents) |
| Young people trained on food systems | 10,741 |
| Out-of-school youth trained/supported | 5,570+ |
| Documented agripreneur transactions (2025) | KES 100 million |
| Agripreneurs who at least doubled earnings | 62% |
| Agripreneur digital use | WhatsApp 87.4%, mobile money 91.5%, digital records 84.4% |
| Digital/ICT capability gain | 51.9% (the lowest of all skills) |
| Adoption intentions | 220,000+; ~66% fully adopted on verification |
| 2028 ambition | 2M farmers; 6,000–50,000 agripreneurs |

## 3. Personas

### Persona A: Mama Achieng, smallholder poultry farmer (Busia)
- 40s, keeps ~50 indigenous chickens, also grows maize. Basic feature phone, shares a smartphone with her son.
- **Says:** "I learnt about vaccinating, but the vaccine is far and I need many birds to make the trip worth it."
- **Thinks:** worries about losing birds to disease; unsure who to tell when something goes wrong.
- **Does:** relies on her local agripreneur; pays via M-Pesa when she has cash.
- **Feels:** motivated after training, then stuck.
- **Pains:** inputs far away and expensive in small quantities; no one to report problems to; middlemen set prices.
- **Gains wanted:** inputs delivered with neighbours; a buyer before the birds are ready; quick answers.

### Persona B: Brian, youth agripreneur (Busia), 24
- Completed the Leadership Academy; serves ~150 farmers; uses WhatsApp and M-Pesa daily.
- **Says:** "Farmers tell me their problems, but I keep it in my head or a notebook."
- **Pains:** collecting orders one by one; chasing suppliers; lenders want collateral he doesn't have; records scattered.
- **Gains wanted:** one place to log everything; bigger orders = better prices; a profile that helps him borrow to grow.

### Persona C: Grace, young woman agripreneur, 22 (single mother)
- Strong business sense; limited time; no land in her name.
- **Pains:** time and labour constraints; land access; travel for inputs.
- **Gains wanted:** fast logging (voice), delivery to her area, finance not tied to land.

### Persona D: Supplier (agro-dealer / hatchery)
- **Pains:** rural demand is small, scattered and unpredictable; last-mile delivery costly.
- **Gains wanted:** pooled, confirmed orders with a delivery point.

### Persona E: Lender (e.g. input-finance partner)
- **Pains:** "invisible" borrowers; small limits (KES 20–50k) because of risk.
- **Gains wanted:** consistent transaction history, repayment signals, explainable profile.

### Persona F: Extension officer (county)
- **Pains:** too many farmers per officer; learns about problems late.
- **Gains wanted:** prioritised list of escalated blockers by area.

### Persona G: Programme manager (UNICEF / GenU)
- **Pains:** self-reported data; conflicting figures across documents; hard to show cost-effectiveness to donors.
- **Gains wanted:** one source of truth; adoption funnel; cost per outcome; early warning by county.

## 4. Journey: today vs with EKYAN Connect (Mama Achieng)
| Step | Today | With EKYAN Connect |
|---|---|---|
| Learns to vaccinate | Training via agripreneur | Same |
| Wants vaccines | Travels alone or gives up | Tells Brian; he logs the order |
| Can't afford/find | Problem stays invisible | Brian logs a **blocker**; it is routed |
| Supplier | Doesn't know she exists | Sees 40 farmers in her area need doses; commits |
| Finance | None | Bundle can attach input finance via Brian's profile |
| Sells birds | Middleman price | Supply forecast shown to buyers |
| Programme sees | A survey months later | Live funnel: intention → order → fulfilled → adopted |

## 5. Design implications
1. The **agripreneur is the interface**; farmer-facing features run through them.
2. Logging must take **under 30 seconds** and work offline.
3. Every blocker needs an **owner and a status**, or the channel loses trust.
4. Pooled demand must show **location and timing**, not just quantity.
5. Finance must not require land or collateral to build a profile.
